<?php

$_['text_title'] = 'Pay with ivendPay';
$_['button_confirm'] = 'Pay with ivendPay';
$_['button_confirm_white_label'] = 'Pay';
$_['button_currency_confirm'] = 'Pay %s with ivendPay';
$_['pay_with_text'] = 'Pay with: ';
$_['text_checkout'] = 'Checkout';
$_['heading_title_customer'] = 'Success';
